Screen_Name = 'Meghdeep'
Help taken:
	1. Tesorflow Documentation- "https://www.tensorflow.org/guide"