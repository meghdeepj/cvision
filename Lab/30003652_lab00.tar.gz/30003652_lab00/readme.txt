Screen_Name = 'Meghdeep'
Help taken:
	1. Argparse tutorial = https://docs.python.org/3/howto/argparse.html